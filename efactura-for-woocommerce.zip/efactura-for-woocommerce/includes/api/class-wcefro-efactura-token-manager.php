<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WCEFRO_Efactura_Token_Manager {

	const OPTION_NAME = 'wcefro_tokens';

	/**
	 * Save tokens to database
	 *
	 * @param string $access_token
	 * @param string $refresh_token
	 * @param int $expires_in Seconds
	 */
	public static function save_tokens( $access_token, $refresh_token, $expires_in ) {
		$data = array(
			'access_token'  => $access_token,
			'refresh_token' => $refresh_token, // Refresh token validity is long (up to 90 days usually)
			'expires_at'    => time() + $expires_in,
			'updated_at'    => time(),
		);
		update_option( self::OPTION_NAME, $data );
	}

	/**
	 * Get valid access token
	 *
	 * @return string|bool Token or false if expired/missing
	 */
	public static function get_access_token() {
		$tokens = get_option( self::OPTION_NAME );
		
		if ( ! $tokens || ! isset( $tokens['access_token'] ) ) {
			return false;
		}

		// Check if expired (with 5 minute buffer)
		if ( time() > ( $tokens['expires_at'] - 300 ) ) {
			return false; // Caller should try refresh
		}

		return $tokens['access_token'];
	}

	public static function get_refresh_token() {
		$tokens = get_option( self::OPTION_NAME );
		return isset( $tokens['refresh_token'] ) ? $tokens['refresh_token'] : false;
	}
	
	public static function clear_tokens() {
		delete_option( self::OPTION_NAME );
	}
	
	public static function has_valid_token() {
		return (bool) self::get_access_token();
	}
}
