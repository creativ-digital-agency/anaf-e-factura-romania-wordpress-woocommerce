<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/class-wcefro-efactura-token-manager.php';

class WCEFRO_Efactura_Anaf_Client {

	private $client_id;
	private $client_secret;
	private $is_test_mode;

	const PROD_AUTH_URL = 'https://logincert.anaf.ro/anaf-oauth2/v1/authorize';
	const PROD_TOKEN_URL = 'https://logincert.anaf.ro/anaf-oauth2/v1/token';
	const PROD_API_URL = 'https://api.anaf.ro'; // Base URL

	const TEST_AUTH_URL = 'https://logincert.anaf.ro/anaf-oauth2/v1/authorize'; // Usually same
	const TEST_TOKEN_URL = 'https://logincert.anaf.ro/anaf-oauth2/v1/token';
	const TEST_API_URL = 'https://api.anaf.ro/test';

	public function __construct() {
		$settings = get_option( 'wcefro_settings' );
		$this->client_id = isset( $settings['client_id'] ) ? $settings['client_id'] : '';
		$this->client_secret = isset( $settings['client_secret'] ) ? $settings['client_secret'] : '';
		$this->is_test_mode = isset( $settings['test_mode'] ) && $settings['test_mode'] == '1';
	}

	public function get_auth_url( $redirect_uri ) {
		$base_url = $this->is_test_mode ? self::TEST_AUTH_URL : self::PROD_AUTH_URL;
		
		$params = array(
			'response_type' => 'code',
			'client_id'     => $this->client_id,
			'redirect_uri'  => $redirect_uri,
			'token_content_type' => 'jwt', // Important for ANAF
		);

		return add_query_arg( $params, $base_url );
	}

	public function exchange_code_for_token( $code, $redirect_uri ) {
		$url = $this->is_test_mode ? self::TEST_TOKEN_URL : self::PROD_TOKEN_URL;
		
		$body = array(
			'grant_type'    => 'authorization_code',
			'code'          => $code,
			'client_id'     => $this->client_id,
			'client_secret' => $this->client_secret,
			'redirect_uri'  => $redirect_uri,
		);

		$response = wp_remote_post( $url, array(
			'body' => $body,
			'timeout' => 30,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $data['access_token'] ) ) {
			// ANAF typically returns expires_in (seconds)
			WCEFRO_Efactura_Token_Manager::save_tokens( 
				$data['access_token'], 
				$data['refresh_token'], 
				$data['expires_in'] 
			);
			return true;
		}

		return new WP_Error( 'anaf_auth_fail', 'Auth failed: ' . json_encode( $data ) );
	}
	
	public function refresh_token() {
		$refresh_token = WCEFRO_Efactura_Token_Manager::get_refresh_token();
		if ( ! $refresh_token ) {
			return new WP_Error( 'no_refresh_token', 'No refresh token available.' );
		}

// ... (skipping unchanged lines) ...

		if ( isset( $data['access_token'] ) ) {
			WCEFRO_Efactura_Token_Manager::save_tokens( 
				$data['access_token'], 
				$data['refresh_token'], 
				$data['expires_in'] 
			);
			return true;
		}

		return new WP_Error( 'anaf_refresh_fail', 'Refresh failed: ' . json_encode( $data ) );
	}

	public function upload_invoice( $xml_content, $cif_upload ) {
		// Ensure we have a valid token
		$token = WCEFRO_Efactura_Token_Manager::get_access_token();
		if ( ! $token ) {
			// Try refresh
			$refresh = $this->refresh_token();
			if ( is_wp_error( $refresh ) ) {
				return $refresh;
			}
			$token = WCEFRO_Efactura_Token_Manager::get_access_token();
		}

		$base_url = $this->is_test_mode ? self::TEST_API_URL : self::PROD_API_URL;
		// Depending on ANAF docs, path might vary slightly.
		// Handling path prefix logic based on is_test_mode
		$path_prefix = $this->is_test_mode ? '/test/FCTEL/rest/upload' : '/prod/FCTEL/rest/upload';
		
		$url = 'https://api.anaf.ro' . $path_prefix;
		
		$url = add_query_arg( array(
			'standard' => 'UBL',
			'cif'      => $cif_upload,
		), $url );

		$response = wp_remote_post( $url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'text/plain', // ANAF expects raw XML body usually
			),
			'body'    => $xml_content,
			'timeout' => 60,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		
		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		
		if ( $code >= 200 && $code < 300 ) {
			// Try decode JSON first (modern ANAF)
			$data = json_decode( $body, true );
			if ( $data && isset( $data['index_incarcare'] ) ) {
				return $data['index_incarcare'];
			} 
			// Fallback if XML response or XML inside string
			// Example raw: <?xml ... <index_incarcare>123</index_incarcare>
			if ( preg_match( '/index_incarcare=["\']?([0-9]+)["\']?/', $body, $matches ) ) {
				return $matches[1];
			}
			// Another common XML pattern
			if ( preg_match( '/<index_incarcare>([0-9]+)<\/index_incarcare>/', $body, $matches ) ) {
				return $matches[1];
			}

			// If we got here, maybe manual check is needed or structure is weird
			// Just return the body in success case if we can't parse index, 
			// but better to error if we can't find ID.
			// Let's return body for debugging if index is missing.
			return array( 'raw_response' => $body ); 
		}
		
		return new WP_Error( 'anaf_upload_fail', 'Upload eșuat (' . $code . '): ' . $body );
	}

	public function check_status( $upload_id ) {
		$token = WCEFRO_Efactura_Token_Manager::get_access_token();
		if ( ! $token ) {
			return new WP_Error( 'no_token', 'Lipsă token acces.' );
		}

		// GET /stare-mesaj?id_incarcare=...
		$path_prefix = $this->is_test_mode ? '/test/FCTEL/rest/stareMesaj' : '/prod/FCTEL/rest/stareMesaj';
		$url = 'https://api.anaf.ro' . $path_prefix;
		
		$url = add_query_arg( 'id_incarcare', $upload_id, $url );

		$response = wp_remote_get( $url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
			),
			'timeout' => 30,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Response example: 
		// {"stare":"ok","id_descarcare":"3333","mesaj":"..."} 
		// or {"stare":"in prelucrare"...}
		
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		
		if ( ! $data || ! isset( $data['stare'] ) ) {
			return new WP_Error( 'anaf_status_fail', 'Răspuns status invalid: ' . substr($body, 0, 100) );
		}
		
		return $data;
	}

	public function download_zip( $download_id ) {
		$token = WCEFRO_Efactura_Token_Manager::get_access_token();
		// GET /descarcare?id=...
		$path_prefix = $this->is_test_mode ? '/test/FCTEL/rest/descarcare' : '/prod/FCTEL/rest/descarcare';
		$url = 'https://api.anaf.ro' . $path_prefix;
		
		$url = add_query_arg( 'id', $download_id, $url );
		
		$response = wp_remote_get( $url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
			),
			'timeout' => 60,
			'stream'  => true, // Large files
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		
		if ( wp_remote_retrieve_response_code( $response ) !== 200 ) {
			return new WP_Error( 'download_fail', 'Download failed: ' . wp_remote_retrieve_response_code( $response ) );
		}
		
		// Typically we'd save this directly to a file, but here we return content
		// Ideally, pass a file handle to wp_remote_get 'filename' arg.
		return wp_remote_retrieve_body( $response );
	}
}
