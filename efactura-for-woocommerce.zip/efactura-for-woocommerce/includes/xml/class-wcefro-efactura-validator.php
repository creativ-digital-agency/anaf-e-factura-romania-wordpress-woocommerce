<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WCEFRO_Efactura_Validator {

	/**
	 * Validate order data before XML generation
	 * 
	 * @param WC_Order $order
	 * @return bool|WP_Error
	 */
	public static function validate_order( $order ) {
		if ( ! $order->get_billing_country() ) {
			return new WP_Error( 'missing_country', 'Billing Country is required.' );
		}
		
		// Future: Check CUI validity with Modulo 11
		
		return true;
	}
}
