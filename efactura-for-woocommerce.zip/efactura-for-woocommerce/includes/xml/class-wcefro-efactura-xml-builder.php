<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WCEFRO_Efactura_XML_Builder {

	/**
	 * Generate UBL 2.1 XML for a given order
	 *
	 * @param WC_Order $order
	 * @return string|WP_Error XML content or error
	 */
	public function generate_invoice_xml( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'invalid_order', 'Invalid Order Object' );
		}

		// Validate company settings
		$settings = get_option( 'wcefro_settings', array() );
		$company_cui = isset( $settings['company_cui'] ) ? trim( $settings['company_cui'] ) : '';
		$company_name = isset( $settings['company_name'] ) ? trim( $settings['company_name'] ) : '';

		if ( empty( $company_cui ) || empty( $company_name ) ) {
			return new WP_Error( 'missing_company_data', 'Configurați CUI și Numele companiei în setările pluginului înainte de a genera facturi.' );
		}

		// Initialize DOMDocument
		$dom = new DOMDocument( '1.0', 'UTF-8' );
		$dom->formatOutput = true;

		// Root Element: Invoice
		$invoice = $dom->createElementNS( 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2', 'Invoice' );
		
		// Add Namespaces
		$invoice->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:cbc', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
		$invoice->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:cac', 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
		$invoice->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:ns4', 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2');
		
		$dom->appendChild( $invoice );

		// 1. General Invoice Info
		$this->add_general_info( $dom, $invoice, $order );

		// 2. Supplier (You)
		$this->add_supplier_party( $dom, $invoice );

		// 3. Customer (Buyer)
		$this->add_customer_party( $dom, $invoice, $order );

		// 4. Tax Totals
		$this->add_tax_total( $dom, $invoice, $order );

		// 5. Legal Monetary Total
		$this->add_legal_monetary_total( $dom, $invoice, $order );

		// 6. Invoice Lines
		$this->add_invoice_lines( $dom, $invoice, $order );

		return $dom->saveXML();
	}

	private function add_cbc( $dom, $parent, $name, $value, $attributes = array() ) {
		$element = $dom->createElement( 'cbc:' . $name, htmlspecialchars( $value ) );
		foreach ( $attributes as $attr => $val ) {
			$element->setAttribute( $attr, $val );
		}
		$parent->appendChild( $element );
	}

	private function add_general_info( $dom, $root, $order ) {
		// CustomizationID for RO-CIUS compliance
		$this->add_cbc( $dom, $root, 'CustomizationID', 'urn:cen.eu:en16931:2017#compliant#urn:efactura.mfinante.ro:RO_CIUS:1.0.1' );
		$this->add_cbc( $dom, $root, 'ID', $order->get_order_number() );
		$this->add_cbc( $dom, $root, 'IssueDate', $order->get_date_created()->date( 'Y-m-d' ) );
		$this->add_cbc( $dom, $root, 'InvoiceTypeCode', '380' ); // 380 = Commercial Invoice
		$this->add_cbc( $dom, $root, 'DocumentCurrencyCode', $order->get_currency() );
	}

	private function add_supplier_party( $dom, $root ) {
		$settings = get_option( 'wcefro_settings', array() );

		$cui = isset( $settings['company_cui'] ) ? trim( $settings['company_cui'] ) : '';
		$name = isset( $settings['company_name'] ) ? trim( $settings['company_name'] ) : '';

		$cac_party = $dom->createElement( 'cac:AccountingSupplierParty' );
		$root->appendChild( $cac_party );

		$party = $dom->createElement( 'cac:Party' );
		$cac_party->appendChild( $party );

		// Legal Entity
		$legal_entity = $dom->createElement( 'cac:PartyLegalEntity' );
		$party->appendChild( $legal_entity );

		$this->add_cbc( $dom, $legal_entity, 'RegistrationName', $name );
		$this->add_cbc( $dom, $legal_entity, 'CompanyID', $cui );
	}

	private function add_customer_party( $dom, $root, $order ) {
		$cac_party = $dom->createElement( 'cac:AccountingCustomerParty' );
		$root->appendChild( $cac_party );
		
		$party = $dom->createElement( 'cac:Party' );
		$cac_party->appendChild( $party );
		
		$billing_company = $order->get_billing_company();
		// Extract CUI from order meta if set, otherwise assume standard fields
		$customer_cui = $order->get_meta( '_billing_cui' ); 
		
		// PartyLegalEntity
		$legal_entity = $dom->createElement( 'cac:PartyLegalEntity' );
		$party->appendChild( $legal_entity );
		
		if ( ! empty( $billing_company ) ) {
			$this->add_cbc( $dom, $legal_entity, 'RegistrationName', $billing_company );
			if ( $customer_cui ) {
				$this->add_cbc( $dom, $legal_entity, 'CompanyID', $customer_cui );
			}
		} else {
			// B2C
			$this->add_cbc( $dom, $legal_entity, 'RegistrationName', $order->get_formatted_billing_full_name() );
		}
		
		// Address
		$address = $dom->createElement( 'cac:PostalAddress' );
		$party->appendChild( $address );
		$this->add_cbc( $dom, $address, 'CityName', $order->get_billing_city() );
		$this->add_cbc( $dom, $address, 'CountrySubentity', $order->get_billing_state() );
		
		$country = $dom->createElement( 'cac:Country' );
		$address->appendChild( $country );
		$this->add_cbc( $dom, $country, 'IdentificationCode', $order->get_billing_country() );
	}

	private function add_tax_total( $dom, $root, $order ) {
		$tax_total = $dom->createElement( 'cac:TaxTotal' );
		$root->appendChild( $tax_total );
		
		$this->add_cbc( $dom, $tax_total, 'TaxAmount', $order->get_total_tax(), array( 'currencyID' => $order->get_currency() ) );
		
		// Loop through taxes to add Subtotals (Mandatory for RO-CIUS)
		foreach ( $order->get_tax_totals() as $code => $tax ) {
			$subtotal = $dom->createElement( 'cac:TaxSubtotal' );
			$tax_total->appendChild( $subtotal );
			
			$this->add_cbc( $dom, $subtotal, 'TaxableAmount', $tax->amount, array( 'currencyID' => $order->get_currency() ) ); // This logic needs refining for actual base
			$this->add_cbc( $dom, $subtotal, 'TaxAmount', $tax->amount, array( 'currencyID' => $order->get_currency() ) );
			
			$category = $dom->createElement( 'cac:TaxCategory' );
			$subtotal->appendChild( $category );
			$this->add_cbc( $dom, $category, 'ID', 'S' ); // Standard rate assumption for now
			$this->add_cbc( $dom, $category, 'Percent', '19' ); // Hardcoded for demo, need to fetch from Tax Rate
			
			$scheme = $dom->createElement( 'cac:TaxScheme' );
			$category->appendChild( $scheme );
			$this->add_cbc( $dom, $scheme, 'ID', 'VAT' );
		}
	}

	private function add_legal_monetary_total( $dom, $root, $order ) {
		$total = $dom->createElement( 'cac:LegalMonetaryTotal' );
		$root->appendChild( $total );
		
		$this->add_cbc( $dom, $total, 'LineExtensionAmount', $order->get_subtotal(), array( 'currencyID' => $order->get_currency() ) );
		$this->add_cbc( $dom, $total, 'TaxExclusiveAmount', $order->get_subtotal(), array( 'currencyID' => $order->get_currency() ) );
		$this->add_cbc( $dom, $total, 'TaxInclusiveAmount', $order->get_total(), array( 'currencyID' => $order->get_currency() ) );
		$this->add_cbc( $dom, $total, 'PayableAmount', $order->get_total(), array( 'currencyID' => $order->get_currency() ) );
	}

	private function add_invoice_lines( $dom, $root, $order ) {
		foreach ( $order->get_items() as $item_id => $item ) {
			$line = $dom->createElement( 'cac:InvoiceLine' );
			$root->appendChild( $line );
			
			$this->add_cbc( $dom, $line, 'ID', $item_id );
			
			// Dynamic Unit Mapping
			// 1. Try to get Product meta '_efactura_unit_code'
			// 2. Map from text (e.g. 'kg', 'buc') if possible (future feature)
			// 3. Fallback to H87 (Piece)
			$product = $item->get_product();
			$unit_code = 'H87'; 
			if ( $product && $product->get_meta( '_efactura_unit_code' ) ) {
				$unit_code = $product->get_meta( '_efactura_unit_code' );
			}
			
			$this->add_cbc( $dom, $line, 'InvoicedQuantity', $item->get_quantity(), array( 'unitCode' => $unit_code ) ); 
			$this->add_cbc( $dom, $line, 'LineExtensionAmount', $item->get_subtotal(), array( 'currencyID' => $order->get_currency() ) );
			
			// Item
			$item_node = $dom->createElement( 'cac:Item' );
			$line->appendChild( $item_node );
			$this->add_cbc( $dom, $item_node, 'Name', $item->get_name() );
			
			// Price
			$price = $dom->createElement( 'cac:Price' );
			$line->appendChild( $price );
			
			$unit_price = $item->get_subtotal() / $item->get_quantity(); // Calc unit price ex tax
			$this->add_cbc( $dom, $price, 'PriceAmount', number_format($unit_price, 2, '.', ''), array( 'currencyID' => $order->get_currency() ) );
		}
	}
}
