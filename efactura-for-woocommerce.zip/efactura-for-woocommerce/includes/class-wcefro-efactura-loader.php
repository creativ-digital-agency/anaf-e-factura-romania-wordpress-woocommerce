<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register all actions and filters for the plugin.
 */
class WCEFRO_Efactura_Loader {

	/**
	 * The loader that is responsible for maintaining and registering all hooks that power
	 * the plugin.
	 */
	protected $loader;

	/**
	 * Define the core functionality of the plugin.
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->define_admin_hooks();
		$this->define_public_hooks();
	}

	/**
	 * Load the required dependencies for this plugin.
	 */
	private function load_dependencies() {
		require_once WCEFRO_PLUGIN_DIR . 'includes/class-wcefro-efactura-i18n.php';
		require_once WCEFRO_PLUGIN_DIR . 'includes/admin/class-wcefro-efactura-admin.php';
		require_once WCEFRO_PLUGIN_DIR . 'includes/background/class-wcefro-efactura-scheduler.php';

		new WCEFRO_Efactura_Scheduler(); // Initialize to register hooks
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 */
	private function define_admin_hooks() {
		$plugin_admin = new WCEFRO_Efactura_Admin( 'wcefro', WCEFRO_VERSION );

		// Add menu item
		add_action( 'admin_menu', array( $plugin_admin, 'add_plugin_admin_menu' ) );
		// Register settings
		add_action( 'admin_init', array( $plugin_admin, 'register_settings' ) );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 */
	private function define_public_hooks() {
		$plugin_i18n = new WCEFRO_Efactura_i18n();
		add_action( 'plugins_loaded', array( $plugin_i18n, 'load_plugin_textdomain' ) );

		require_once WCEFRO_PLUGIN_DIR . 'includes/frontend/class-wcefro-efactura-checkout.php';
		new WCEFRO_Efactura_Checkout();
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 */
	public function run() {
		// In a more complex setup, we might have a separate orchestrator class.
		// For now, the hooks are added in the constructor/methods above.
	}
}
