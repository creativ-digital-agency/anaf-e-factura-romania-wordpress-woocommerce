<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define the internationalization functionality.
 */
class WCEFRO_Efactura_i18n {

	/**
	 * Load the plugin text domain for translation.
	 */
	public function load_plugin_textdomain() {
		// WordPress.org handles this automatically. Kept for back-compat if needed, but empty for now to satisfy checker.
	}
}
