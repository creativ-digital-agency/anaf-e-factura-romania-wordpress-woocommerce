<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The admin-specific functionality of the plugin.
 */
class WCEFRO_Efactura_Admin {

	private $plugin_name;
	private $version;

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		
		add_action( 'admin_init', array( $this, 'handle_oauth_callback' ) );

		// Order Metabox
		add_action( 'add_meta_boxes', array( $this, 'add_order_metabox' ) );
		add_action( 'wp_ajax_wcefro_generate_xml', array( $this, 'ajax_generate_xml' ) );
		add_action( 'wp_ajax_wcefro_upload_xml', array( $this, 'ajax_upload_xml' ) );

		// Enqueue admin scripts and styles
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		// Automation Hook
		add_action( 'woocommerce_order_status_completed', array( $this, 'automate_invoice_sending' ) );
	}

	/**
	 * Enqueue admin scripts and styles
	 */
	public function enqueue_admin_assets( $hook ) {
		// Enqueue for order edit pages (metabox JS)
		global $post, $post_type;
		$screen = get_current_screen();

		// Check if we're on an order page
		if ( ( 'post.php' === $hook && 'shop_order' === $post_type ) ||
		     ( isset( $screen->id ) && 'woocommerce_page_wc-orders' === $screen->id ) ) {

			// Get order to pass data to JS
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading WordPress core order ID parameter
			$order_id = isset( $_GET['id'] ) ? intval( $_GET['id'] ) : ( isset( $post->ID ) ? $post->ID : 0 );

			if ( $order_id ) {
				// Inline script for metabox
				$inline_js = "
				jQuery(document).ready(function($) {
					$('#wcefro_generate').on('click', function() {
						var data = {
							'action': 'wcefro_generate_xml',
							'order_id': " . esc_js( $order_id ) . ",
							'nonce': '" . esc_js( wp_create_nonce( 'wcefro_nonce' ) ) . "'
						};
						$.post(ajaxurl, data, function(response) {
							$('#wcefro_messages').html(response.data.message);
						});
					});

					$('#wcefro_upload').on('click', function() {
						var data = {
							'action': 'wcefro_upload_xml',
							'order_id': " . esc_js( $order_id ) . ",
							'nonce': '" . esc_js( wp_create_nonce( 'wcefro_nonce' ) ) . "'
						};
						$.post(ajaxurl, data, function(response) {
							$('#wcefro_messages').html(response.data.message);
						});
					});
				});
				";
				wp_add_inline_script( 'jquery', $inline_js );
			}
		}

		// Enqueue for plugin settings page
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading WordPress core admin page parameter
		if ( isset( $_GET['page'] ) && 'wcefro' === $_GET['page'] ) {
			$inline_css = "
			.efactura-admin-container { display: flex; flex-wrap: wrap; gap: 20px; margin-top: 20px; max-width: 1200px; }
			.efactura-main { flex: 2; min-width: 300px; background: #fff; border: 1px solid #c3c4c7; padding: 20px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
			.efactura-sidebar { flex: 1; min-width: 280px; }
			.efactura-card { background: #fff; border: 1px solid #c3c4c7; padding: 15px; margin-bottom: 20px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
			.efactura-card h3 { margin-top: 0; padding-bottom: 10px; border-bottom: 1px solid #f0f0f1; }
			.status-connected { color: #007017; font-weight: bold; background: #edfaef; padding: 10px; border-left: 4px solid #007017; display:block; margin-bottom:15px; }
			.status-disconnected { color: #d63638; font-weight: bold; background: #fcf0f1; padding: 10px; border-left: 4px solid #d63638; display:block; margin-bottom:15px; }
			.efactura-code-block { background: #f6f7f7; padding: 10px; font-family: monospace; border: 1px solid #dcdcde; word-break: break-all; user-select: all; }
			";
			wp_add_inline_style( 'wp-admin', $inline_css );
		}
	}

	public function add_order_metabox() {
		add_meta_box(
			'wcefro_box',
			'e-Factura ANAF',
			array( $this, 'render_order_metabox' ),
			'shop_order',
			'side',
			'high'
		);
		// also support HPOS
		add_meta_box(
			'wcefro_box',
			'e-Factura ANAF',
			array( $this, 'render_order_metabox' ),
			'woocommerce_page_wc-orders',
			'side',
			'high'
		);
	}

	public function render_order_metabox( $post_or_order_object ) {
		$order = ( $post_or_order_object instanceof WP_Post ) ? wc_get_order( $post_or_order_object->ID ) : $post_or_order_object;
		
		if ( ! $order ) return;

		// Check if XML exists
		$xml_exists = false; // TODO: Check filesystem/meta
		
		?>
		<div class="wcefro-actions">
			<p>
				<button type="button" class="button button-primary" id="wcefro_generate">Generează XML</button>
			</p>
			<p>
				<button type="button" class="button" id="wcefro_upload">Trimite la ANAF</button>
			</p>
			<hr>
			<p><strong>Status:</strong> <span id="wcefro_status">Neinițiat</span></p>
			<div id="wcefro_messages"></div>
		</div>
		<?php
	}

	public function ajax_generate_xml() {
		check_ajax_referer( 'wcefro_nonce', 'nonce' );
		
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ) );
		}
		
		$order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
		$order = wc_get_order( $order_id );
		
		if ( ! $order ) {
			wp_send_json_error( array( 'message' => 'Order not found' ) );
		}
		
		require_once WCEFRO_PLUGIN_DIR . 'includes/xml/class-wcefro-efactura-xml-builder.php';
		$builder = new WCEFRO_Efactura_XML_Builder();
		$xml = $builder->generate_invoice_xml( $order );
		
		if ( is_wp_error( $xml ) ) {
			wp_send_json_error( array( 'message' => $xml->get_error_message() ) );
		}
		
		// Save XML to Uploads
		$upload_dir = wp_upload_dir();
		$file_path = $upload_dir['basedir'] . '/efactura/xml/';
			if ( ! file_exists( $file_path ) ) {
				wp_mkdir_p( $file_path );
			}
		
		$filename = 'factura_' . $order->get_order_number() . '.xml';
		file_put_contents( $file_path . $filename, $xml );
		
		// Save meta
		$order->update_meta_data( '_efactura_xml_file', $filename );
		$order->save();
		
		wp_send_json_success( array( 'message' => 'XML Generat cu succes! <a href="' . $upload_dir['baseurl'] . '/efactura/xml/' . $filename . '" target="_blank">Descarcă</a>' ) );
	}
	
	public function ajax_upload_xml() {
		check_ajax_referer( 'wcefro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ) );
		}
		
		$order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
		$order = wc_get_order( $order_id );
		
		if ( ! $order ) {
			wp_send_json_error( array( 'message' => 'Order not found' ) );
		}
		
		$filename = $order->get_meta( '_efactura_xml_file' );
		if ( ! $filename ) {
			wp_send_json_error( array( 'message' => 'Nu există XML generat. Generați mai întâi XML-ul.' ) );
		}
		
		$upload_dir = wp_upload_dir();
		$file_path = $upload_dir['basedir'] . '/efactura/xml/' . $filename;
		
		if ( ! file_exists( $file_path ) ) {
			wp_send_json_error( array( 'message' => 'Fișierul XML nu a fost găsit pe disc.' ) );
		}
		
		$xml_content = file_get_contents( $file_path );
		
		// Get Client
		require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-anaf-client.php';
		$client = new WCEFRO_Efactura_Anaf_Client();
		
		// Get upload CUI from settings
		$settings = get_option( 'wcefro_settings' );
		$cui_upload = isset( $settings['company_cui'] ) ? $settings['company_cui'] : '';
		
		// If settings empty, maybe provide fallback or error?
		if ( empty( $cui_upload ) ) {
			wp_send_json_error( array( 'message' => 'CUI-ul companiei nu este setat în configurare.' ) ); 
		}
		
		$result = $client->upload_invoice( $xml_content, $cui_upload );


		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		} else if ( is_array( $result ) && isset( $result['raw_response'] ) ) {
             // Fallback warning
             wp_send_json_success( array( 'message' => 'Încărcat, dar ID-ul nu a fost parsabil automat. Răspuns: ' . esc_html( substr($result['raw_response'], 0, 100) ) ) );
        } else {
			// Success - $result is ID
			$order->update_meta_data( '_efactura_upload_id', $result );
			$order->add_order_note( 'e-Factura trimisă cu succes. Index încărcare: ' . $result );
			$order->save();
			
			wp_send_json_success( array( 'message' => 'Factura trimisă cu succes! Index: ' . $result ) );
		}
	}

	public function automate_invoice_sending( $order_id ) {
		$options = get_option( 'wcefro_settings' );
		if ( empty( $options['auto_send'] ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) return;
		
		// Avoid duplicates
		if ( $order->get_meta( '_efactura_upload_id' ) ) {
			return; 
		}

		// 1. Generate XML if needed
		$filename = $order->get_meta( '_efactura_xml_file' );
		if ( ! $filename || ! file_exists( wp_upload_dir()['basedir'] . '/efactura/xml/' . $filename ) ) {
			require_once WCEFRO_PLUGIN_DIR . 'includes/xml/class-wcefro-efactura-xml-builder.php';
			$builder = new WCEFRO_Efactura_XML_Builder();
			$xml = $builder->generate_invoice_xml( $order );
			
			if ( is_wp_error( $xml ) ) {
				$order->add_order_note( 'Auto-eFactura Eșuată: ' . $xml->get_error_message() );
				return;
			}
			
			$upload_dir = wp_upload_dir();
			$file_path = $upload_dir['basedir'] . '/efactura/xml/';
			if ( ! file_exists( $file_path ) ) {
				wp_mkdir_p( $file_path );
			}
			
			$filename = 'factura_' . $order->get_order_number() . '.xml';
			file_put_contents( $file_path . $filename, $xml );
			$order->update_meta_data( '_efactura_xml_file', $filename );
			$order->save();
		}

		// 2. Upload
		require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-anaf-client.php';
		$client = new WCEFRO_Efactura_Anaf_Client();
		
		$cui_upload = isset( $options['company_cui'] ) ? $options['company_cui'] : '';
		if ( empty( $cui_upload ) ) {
			$order->add_order_note( 'Auto-eFactura Eșuată: Lipsește CUI companie.' );
			return;
		}

		$file_path = wp_upload_dir()['basedir'] . '/efactura/xml/' . $filename;
		$xml_content = file_get_contents( $file_path );
		
		$result = $client->upload_invoice( $xml_content, $cui_upload );
		
		if ( is_wp_error( $result ) ) {
			$order->add_order_note( 'Auto-eFactura Upload Eșuat: ' . $result->get_error_message() );
		} elseif ( is_array( $result ) && isset( $result['raw_response'] ) ) {
			$order->add_order_note( 'Auto-eFactura: Uploadat dar ID neparsabil.' );
		} else {
			$order->update_meta_data( '_efactura_upload_id', $result );
			$order->add_order_note( 'Auto-eFactura trimisă! Index: ' . $result );
			$order->save();
		}
	}

	public function add_plugin_admin_menu() {
		add_submenu_page(
			'woocommerce',
			'RO e-Factura',
			'RO e-Factura',
			'manage_woocommerce',
			'wcefro',
			array( $this, 'display_plugin_setup_page' )
		);
	}

	/**
	 * Add specific settings for the plugin
	 */
	public function register_settings() {
		register_setting( 'wcefro_options', 'wcefro_settings', array( $this, 'sanitize_settings' ) );

		add_settings_section(
			'wcefro_api_section',
			'Setări API ANAF (SPV)',
			array( $this, 'api_section_callback' ),
			'wcefro'
		);

		add_settings_field(
			'client_id',
			'Client ID',
			array( $this, 'client_id_callback' ),
			'wcefro',
			'wcefro_api_section'
		);

		add_settings_field(
			'client_secret',
			'Client Secret',
			array( $this, 'client_secret_callback' ),
			'wcefro',
			'wcefro_api_section'
		);
		
		add_settings_field(
			'test_mode',
			'Mod Test (Sandbox)',
			array( $this, 'test_mode_callback' ),
			'wcefro',
			'wcefro_api_section'
		);
		
		add_settings_field(
			'auto_send',
			'Automatizare',
			array( $this, 'auto_send_callback' ),
			'wcefro',
			'wcefro_api_section'
		);
		
		add_settings_section(
			'wcefro_company_section',
			'Detalii Companie',
			array( $this, 'company_section_callback' ),
			'wcefro'
		);

		add_settings_field(
			'company_name',
			'Nume Companie (SRL)',
			array( $this, 'company_name_callback' ),
			'wcefro',
			'wcefro_company_section'
		);

		add_settings_field(
			'company_cui',
			'CUI (fără RO)',
			array( $this, 'company_cui_callback' ),
			'wcefro',
			'wcefro_company_section'
		);
	}
	
	public function company_section_callback() {
		echo '<p>Datele companiei tale care vor apărea pe factură.</p>';
	}
	
	public function company_name_callback() {
		$options = get_option( 'wcefro_settings' );
		$value = isset( $options['company_name'] ) ? esc_attr( $options['company_name'] ) : '';
		echo "<input type='text' name='wcefro_settings[company_name]' value='" . esc_attr( $value ) . "' class='regular-text' />";
	}

	public function company_cui_callback() {
		$options = get_option( 'wcefro_settings' );
		$value = isset( $options['company_cui'] ) ? esc_attr( $options['company_cui'] ) : '';
		echo "<input type='text' name='wcefro_settings[company_cui]' value='" . esc_attr( $value ) . "' class='regular-text' />";
	}

	public function handle_oauth_callback() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- OAuth callback from ANAF, nonce not applicable
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'wcefro' && isset( $_GET['code'] ) ) {
			// Verify user has admin capabilities
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				return;
			}

			// This is an OAuth callback
			require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-anaf-client.php';

			$client = new WCEFRO_Efactura_Anaf_Client();
			$redirect_uri = admin_url( 'admin.php?page=wcefro' );

			// Sanitize input
			$code = sanitize_text_field( wp_unslash( $_GET['code'] ) );
			$result = $client->exchange_code_for_token( $code, $redirect_uri );

			if ( is_wp_error( $result ) ) {
				add_settings_error( 'wcefro_settings', 'auth_fail', 'Autentificare eșuată: ' . $result->get_error_message() );
			} else {
				add_settings_error( 'wcefro_settings', 'auth_success', 'Autentificare reușită cu succes la ANAF!', 'success' );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}

	public function api_section_callback() {
		echo '<p>' . esc_html__( 'Completează datele de identificare pentru a conecta magazinul la ANAF SPV.', 'efactura-for-woocommerce' ) . '</p>';
	}

	public function client_id_callback() {
		$options = get_option( 'wcefro_settings' );
		$value = isset( $options['client_id'] ) ? esc_attr( $options['client_id'] ) : '';
		echo "<input type='text' name='wcefro_settings[client_id]' value='" . esc_attr( $value ) . "' class='regular-text' />";
	}

	public function client_secret_callback() {
		$options = get_option( 'wcefro_settings' );
		$value = isset( $options['client_secret'] ) ? esc_attr( $options['client_secret'] ) : '';
		echo "<input type='password' name='wcefro_settings[client_secret]' value='" . esc_attr( $value ) . "' class='regular-text' />";
	}
	
	public function test_mode_callback() {
		$options = get_option( 'wcefro_settings' );
		$checked = isset( $options['test_mode'] ) && $options['test_mode'] ? 'checked' : '';
		echo "<input type='checkbox' name='wcefro_settings[test_mode]' value='1' " . esc_attr( $checked ) . ' /> ' . esc_html__( 'Folosește mediul de test ANAF (Sandbox)', 'efactura-for-woocommerce' );
	}

	public function auto_send_callback() {
		$options = get_option( 'wcefro_settings' );
		$checked = isset( $options['auto_send'] ) && $options['auto_send'] ? 'checked' : '';
		echo "<input type='checkbox' name='wcefro_settings[auto_send]' value='1' " . esc_attr( $checked ) . ' /> <strong>' . esc_html__( 'Auto-Pilot:', 'efactura-for-woocommerce' ) . '</strong> ' . esc_html__( "Trimite automat factura la ANAF când comanda este 'Finalizată'", 'efactura-for-woocommerce' );
	}


	/**
	 * Render the Settings Page (2-Column Layout)
	 */
	public function display_plugin_setup_page() {
		require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-token-manager.php';
		$is_connected = WCEFRO_Efactura_Token_Manager::has_valid_token();
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">Configurare RO e-Factura</h1>
			<p class="description">Gestionează conexiunea cu ANAF și setările de facturare automată.</p>
			
			<div class="efactura-admin-container">
				<!-- Left Column: Settings Form -->
				<div class="efactura-main">
					<form action="options.php" method="post">
						<?php
						settings_fields( 'wcefro_options' );
						do_settings_sections( 'wcefro' );
						submit_button('Salvează Setările');
						?>
					</form>
				</div>
				
				<!-- Right Column: Sidebar Info & Actions -->
				<div class="efactura-sidebar">
				
					<!-- Card 1: Connection Status -->
					<div class="efactura-card">
						<h3>Status Conexiune</h3>
						<?php if ( $is_connected ) : ?>
							<div class="status-connected">✅ CONECTAT LA SPV</div>
							<p>Pluginul este autorizat și funcționează.</p>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcefro&disconnect=true' ) ); ?>" class="button button-link-delete">Deconectare Cont</a>
						<?php else : ?>
							<div class="status-disconnected">❌ NECONECTAT</div>
							<p>Pentru a activa trimiterea facturilor, trebuie să autorizezi aplicația.</p>
							
							<?php 
							$options = get_option( 'wcefro_settings' );
							if ( ! empty( $options['client_id'] ) && ! empty( $options['client_secret'] ) ) : 
								require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-anaf-client.php';
								$client = new WCEFRO_Efactura_Anaf_Client();
								$redirect_uri = admin_url( 'admin.php?page=wcefro' );
								$auth_url = $client->get_auth_url( $redirect_uri );
							?>
								<a href="<?php echo esc_url( $auth_url ); ?>" class="button button-primary button-large" style="width:100%; text-align:center;">Conectează la ANAF</a>
							<?php else : ?>
								<p><em>Salvați Client ID și Secret în formular pentru a activa butonul de conectare.</em></p>
							<?php endif; ?>
						<?php endif; ?>
					</div>

					<!-- Card 2: Instructions -->
					<div class="efactura-card">
						<h3>Instrucțiuni Configurare</h3>
						<ol style="margin-left: 1.5em; list-style-type: decimal;">
							<li>Mergi la <a href="https://pfinternet.anaf.ro" target="_blank">Portalul ANAF</a> &rarr; Dezvoltatori Aplicații &rarr; Adaugă aplicație.</li>
							<li>La <strong>Redirect URI</strong> (Callback URL), copiază exact:
								<div class="efactura-code-block"><?php echo esc_url( admin_url( 'admin.php?page=wcefro' ) ); ?></div>
							</li>
							<li>Copiază <strong>Client ID</strong> și <strong>Client Secret</strong> în formularul din stânga și salvează.</li>
						</ol>
						
						<hr style="margin: 15px 0;">
						<h4>Informații Tehnice</h4>
						<ul class="ul-square" style="font-size: 12px; color: #666; list-style-type: square; margin-left: 1.5em;">
							<li><strong>OAuth2:</strong> Authorization Code Flow.</li>
							<li><strong>Access Token:</strong> 90 zile (Auto-Refresh).</li>
							<li><strong>API:</strong> UBL 2.1 / RO-CIUS.</li>
						</ul>
					</div>

					<!-- Card 3: Support -->
					<div class="efactura-card">
						<h3>Suport Tehnic</h3>
						<p>Dezvoltat de <a href="https://creativdigital.ro" target="_blank">Creativ Digital Agency</a>.</p>
						<p>Întâmpini probleme?</p>
						<a href="mailto:office@creativdigital.ro" class="button">Contactează Suport</a>
						<p class="description" style="margin-top:5px;">Răspundem în maxim 48h.</p>
					</div>

				</div>
			</div>
		</div>
		<?php
	}
}
