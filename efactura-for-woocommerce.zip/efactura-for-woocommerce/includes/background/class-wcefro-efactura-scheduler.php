<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WCEFRO_Efactura_Scheduler {

	public function __construct() {
		add_action( 'init', array( $this, 'schedule_events' ) );
		
		add_action( 'wcefro_check_pending_updates', array( $this, 'process_pending_updates' ) );
		add_action( 'wcefro_weekly_token_refresh', array( $this, 'process_token_refresh' ) );
	}
	
	public function schedule_events() {
		if ( false === as_next_scheduled_action( 'wcefro_check_pending_updates' ) ) {
			as_schedule_recurring_action( time(), 3600, 'wcefro_check_pending_updates' ); // Every hour
		}
		
		if ( false === as_next_scheduled_action( 'wcefro_weekly_token_refresh' ) ) {
			as_schedule_recurring_action( time(), WEEK_IN_SECONDS, 'wcefro_weekly_token_refresh' );
		}
	}
	
	public function process_token_refresh() {
		require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-anaf-client.php';
		$client = new WCEFRO_Efactura_Anaf_Client();
		$client->refresh_token(); // Keep token alive long-term
	}

	public function process_pending_updates() {
		// Find orders with status 'pending_anaf' (custom) or verify meta
		// For simplicity, we search for orders with _efactura_upload_id AND NOT _efactura_download_id

		// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required to find pending ANAF invoice uploads
		$args = array(
			'limit' => 20,
			'return' => 'ids',
			'meta_query' => array(
				'relation' => 'AND',
				array(
					'key' => '_efactura_upload_id',
					'compare' => 'EXISTS',
				),
				array(
					'key' => '_efactura_download_id',
					'compare' => 'NOT EXISTS',
				),
			),
		);
		// phpcs:enable WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		
		$orders = wc_get_orders( $args );
		
		if ( empty( $orders ) ) return;
		
		require_once WCEFRO_PLUGIN_DIR . 'includes/api/class-wcefro-efactura-anaf-client.php';
		$client = new WCEFRO_Efactura_Anaf_Client();
		
		foreach ( $orders as $order_id ) {
			$order = wc_get_order( $order_id );
			$upload_id = $order->get_meta( '_efactura_upload_id' );
			
			$status_data = $client->check_status( $upload_id );
			
			if ( is_wp_error( $status_data ) ) {
				// Log error, skip
				continue;
			}
			
			// Check 'stare'
			if ( isset( $status_data['stare'] ) && $status_data['stare'] == 'ok' ) {
				// Valid! ready to download
				if ( isset( $status_data['id_descarcare'] ) ) {
					$download_id = $status_data['id_descarcare'];
					
					// Download ZIP
					$zip_content = $client->download_zip( $download_id );
					
					if ( ! is_wp_error( $zip_content ) ) {
						// Open ZIP and extract PDF (signature.xml is nicely inside)
						// For now, save ZIP
						$upload_dir = wp_upload_dir();
						$file_path = $upload_dir['basedir'] . '/efactura/zips/';
						if ( ! file_exists( $file_path ) ) {
							wp_mkdir_p( $file_path );
						}
						
						$filename = 'anaf_reply_' . $order->get_order_number() . '.zip';
						file_put_contents( $file_path . $filename, $zip_content );
						
						$order->update_meta_data( '_efactura_download_id', $download_id );
						$order->update_meta_data( '_efactura_zip_file', $filename );
						$order->add_order_note( 'e-Factura VALIDATĂ de ANAF. Răspuns descărcat: ' . $filename );
						$order->save();
					}
				}
			} elseif ( isset( $status_data['stare'] ) && $status_data['stare'] == 'nok' ) {
				// Invalid!
				$messages = isset($status_data['mesaj']) ? $status_data['mesaj'] : 'Eroare necunoscută';
				$order->add_order_note( 'e-Factura RESPINSĂ de ANAF: ' . $messages );
				// Remove upload ID so user can regenerate and try again? 
				// Or keep it for history and add a flag 'rejected'.
				$order->update_meta_data( '_efactura_status', 'rejected' );
				$order->save();
			}
			// If 'in prelucrare', do nothing, wait for next hour
		}
	}
}
