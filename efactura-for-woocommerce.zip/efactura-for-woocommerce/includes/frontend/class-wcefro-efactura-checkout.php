<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WCEFRO_Efactura_Checkout {

	public function __construct() {
		add_filter( 'woocommerce_checkout_fields', array( $this, 'add_checkout_fields' ) );
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'save_checkout_fields' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	public function enqueue_scripts() {
		if ( is_checkout() ) {
			wp_enqueue_script( 'wcefro-checkout', WCEFRO_PLUGIN_URL . 'assets/js/checkout.js', array( 'jquery' ), WCEFRO_VERSION, true );
			// Identify if we need to pass translatable strings
		}
	}

	public function add_checkout_fields( $fields ) {
		$fields['billing']['billing_company_cui'] = array(
			'label'       => 'CUI / CIF',
			'placeholder' => 'RO123456',
			'required'    => false, // Optional for PF, required logic usually handled via JS based on Person Type
			'class'       => array( 'form-row-wide' ),
			'priority'    => 35,
		);

		$fields['billing']['billing_reg_com'] = array(
			'label'       => 'Nr. Reg. Com.',
			'placeholder' => 'J40/123/2024',
			'required'    => false,
			'class'       => array( 'form-row-wide' ),
			'priority'    => 36,
		);
		
		$fields['billing']['billing_bank_account'] = array(
			'label'       => 'Cont IBAN (Banca)',
			'placeholder' => '',
			'required'    => false,
			'class'       => array( 'form-row-wide' ),
			'priority'    => 37,
		);
		
		// Add Sector field (Hidden by default via CSS or JS, shown if Bucuresti)
		$fields['billing']['billing_sector'] = array(
			'type'        => 'select',
			'label'       => 'Sector (București)',
			'options'     => array(
				'' => 'Alege sectorul...',
				'SECTOR1' => 'Sector 1',
				'SECTOR2' => 'Sector 2',
				'SECTOR3' => 'Sector 3',
				'SECTOR4' => 'Sector 4',
				'SECTOR5' => 'Sector 5',
				'SECTOR6' => 'Sector 6',
			),
			'required'    => false,
			'class'       => array( 'form-row-wide', 'wcefro-sector-field' ), // Helper class
			'priority'    => 45, // After city/state
		);

		return $fields;
	}

	public function save_checkout_fields( $order_id ) {
		// Verify WooCommerce Nonce for extra security and compliancy
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'woocommerce-process_checkout' ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified above
		if ( ! empty( $_POST['billing_company_cui'] ) ) {
			update_post_meta( $order_id, '_billing_cui', sanitize_text_field( wp_unslash( $_POST['billing_company_cui'] ) ) );
		}
		if ( ! empty( $_POST['billing_reg_com'] ) ) {
			update_post_meta( $order_id, '_billing_reg_com', sanitize_text_field( wp_unslash( $_POST['billing_reg_com'] ) ) );
		}
		if ( ! empty( $_POST['billing_bank_account'] ) ) {
			update_post_meta( $order_id, '_billing_bank_account', sanitize_text_field( wp_unslash( $_POST['billing_bank_account'] ) ) );
		}
		if ( ! empty( $_POST['billing_sector'] ) ) {
			update_post_meta( $order_id, '_billing_sector', sanitize_text_field( wp_unslash( $_POST['billing_sector'] ) ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

}
