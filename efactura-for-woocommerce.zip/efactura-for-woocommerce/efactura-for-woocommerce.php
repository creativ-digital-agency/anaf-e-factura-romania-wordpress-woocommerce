<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Plugin Name: e-Factura for WooCommerce
 * Plugin URI: https://creativdigital.ro/servicii/wordpress
 * Description: Direct integration with ANAF e-Factura SPV for WooCommerce. Generates UBL 2.1 XML and automates submission.
 * Version: 1.0.2
 * Author: Creativ Digital Agency
 * Author URI: https://creativdigital.ro
 * License: GPLv2 or later
 * Text Domain: efactura-for-woocommerce
 * Domain Path: /languages
 * Requires Plugins: woocommerce
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Validating the plugin version constant.
 */
if ( ! defined( 'WCEFRO_VERSION' ) ) {
	define( 'WCEFRO_VERSION', '1.0.2' );
}

/**
 * Common constants
 */
define( 'WCEFRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCEFRO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
// Check dependencies
if ( ! class_exists( 'WooCommerce' ) ) {
	// If loaded too early, we might fallback to plugins_loaded logic, but let's keep it safe.
}

if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/class-wcefro-efactura-loader.php' ) ) {
	require plugin_dir_path( __FILE__ ) . 'includes/class-wcefro-efactura-loader.php';
}

/**
 * Begins execution of the plugin.
 */
function wcefro_run() {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	if ( class_exists( 'WCEFRO_Efactura_Loader' ) ) {
		$plugin = new WCEFRO_Efactura_Loader();
		$plugin->run();
	}

}
add_action( 'plugins_loaded', 'wcefro_run', 11 );


