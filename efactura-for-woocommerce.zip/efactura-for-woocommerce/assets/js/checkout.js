jQuery(document).ready(function($) {
	// Sector Logic
	var cityField = $('#billing_city');
	var sectorRow = $('.wcefro-sector-field').closest('p.form-row');
	
	function toggleSector() {
		var city = cityField.val() || '';
		city = city.toLowerCase().trim();
		
		// Check for variants of Bucharest
		if ( city.indexOf('bucurest') !== -1 || city.indexOf('bucurești') !== -1 ) {
			sectorRow.show();
		} else {
			sectorRow.hide();
			$('#billing_sector').val(''); // Reset if hiding
		}
	}
	
	// Init
	if( sectorRow.length ) {
		toggleSector();
		
		// Listen for city changes. 
		// WooCommerce updates fields via AJAX too, so we listen on document body for 'updated_checkout'
		$('body').on('updated_checkout', function() {
			toggleSector();
		});
		
		cityField.on('change keyup', toggleSector);
	}
});
